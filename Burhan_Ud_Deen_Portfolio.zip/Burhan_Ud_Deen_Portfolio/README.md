# Burhan Ud Deen — Developer Portfolio

A modern, responsive personal bio portfolio created from the Week 1 HTML foundation.

## Student Information

- **Full Name:** Burhan Ud Deen
- **Student ID:** **ADD YOUR STUDENT ID HERE**
- **Program:** BSc Computer Science
- **University:** University of Turbat

## Project Structure

```text
Burhan_Ud_Deen_Portfolio/
├── index.html
├── style.css
├── README.md
└── images/
    └── headshot.svg
```

## Features

- Semantic HTML5 structure with `header`, `nav`, `main`, `section`, and `footer`.
- Responsive hero/profile card.
- Status badge and personal biography.
- Technical skills displayed as modern pill badges.
- Accessible contact form with correctly connected `label` and `input` IDs.
- Google Fonts typography.
- CSS custom properties in `:root`.
- Universal CSS reset.
- Flexbox navigation, hero layout, skill wrapping, and content layouts.
- Subtle borders, spacing, shadows, and modern colour palette.
- Mobile single-column layout at `max-width: 768px`.
- GitHub and LinkedIn footer links.

## Important Before Submission

1. Replace `images/headshot.svg` with your **real headshot photo** if your instructor specifically requires a photograph.
2. In `index.html`, replace the GitHub and LinkedIn placeholder URLs with your real profile URLs.
3. Replace `ADD YOUR STUDENT ID HERE` above with your actual student ID.
4. Open `index.html` in a browser and verify the layout at desktop and mobile widths.

## Preview

The portfolio is designed as a dark, modern developer profile with:
- a responsive navigation bar,
- hero/profile section,
- About section,
- Skills section,
- accessible Contact form,
- and social links in the footer.

## Technologies

HTML5 · CSS3 · Google Fonts · Flexbox · Responsive Media Queries
